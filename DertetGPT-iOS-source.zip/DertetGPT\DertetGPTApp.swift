import SwiftUI
import SwiftData

@main
struct DertetGPTApp: App {
    var body: some Scene {
        WindowGroup {
            AppRootView()
                .preferredColorScheme(.dark)
        }
        .modelContainer(PersistenceController.sharedContainer)
    }
}
