//
//  SettingsView.swift
//  ResertAI
//
//  Налаштування: тема оформлення + локальний акаунт.
//

import SwiftUI

struct SettingsView: View {
    @EnvironmentObject private var settings: SettingsStore
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            ZStack {
                RTheme.backgroundGradient.ignoresSafeArea()

                ScrollView {
                    VStack(spacing: 20) {
                        themeSection

                        if settings.isLoggedIn {
                            accountSummarySection
                        } else {
                            AuthSection()
                        }
                    }
                    .padding(16)
                }
            }
            .navigationTitle("Налаштування")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Готово") { dismiss() }
                        .fontWeight(.semibold)
                }
            }
        }
    }

    // MARK: Тема

    private var themeSection: some View {
        SettingsCard(title: "Тема оформлення") {
            HStack(spacing: 10) {
                ForEach(AppTheme.allCases) { theme in
                    ThemeOptionButton(
                        theme: theme,
                        isSelected: settings.theme == theme
                    ) {
                        withAnimation(.easeOut(duration: 0.2)) {
                            settings.theme = theme
                        }
                    }
                }
            }
        }
    }

    // MARK: Акаунт (вже зареєстрований)

    private var accountSummarySection: some View {
        SettingsCard(title: "Акаунт") {
            HStack(spacing: 14) {
                Circle()
                    .fill(RTheme.brandGradient)
                    .frame(width: 46, height: 46)
                    .overlay(
                        Text(initials)
                            .font(.system(.headline, design: .rounded, weight: .bold))
                            .foregroundStyle(.white)
                    )

                VStack(alignment: .leading, spacing: 2) {
                    Text(settings.accountName.isEmpty ? "Без імені" : settings.accountName)
                        .font(.system(.body, design: .rounded, weight: .semibold))
                        .foregroundStyle(RTheme.ink)
                    Text(settings.accountEmail)
                        .font(.system(.footnote, design: .rounded))
                        .foregroundStyle(RTheme.inkMuted)
                }

                Spacer()
            }

            Button(role: .destructive) {
                settings.signOut()
            } label: {
                Text("Вийти")
                    .font(.system(.subheadline, design: .rounded, weight: .semibold))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
                    .background(Color.red.opacity(0.1), in: RoundedRectangle(cornerRadius: 14))
                    .foregroundStyle(.red)
            }
            .padding(.top, 4)
        }
    }

    private var initials: String {
        let parts = settings.accountName.split(separator: " ")
        let letters = parts.prefix(2).compactMap { $0.first }
        return letters.isEmpty ? "?" : String(letters).uppercased()
    }
}

// MARK: - Картка-контейнер

private struct SettingsCard<Content: View>: View {
    let title: String
    @ViewBuilder let content: Content

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(title)
                .font(.system(.subheadline, design: .rounded, weight: .semibold))
                .foregroundStyle(RTheme.inkMuted)

            content
        }
        .padding(16)
        .background(RTheme.card, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .stroke(RTheme.cardStroke, lineWidth: 1)
        )
        .shadow(color: RTheme.cardShadow, radius: 8, y: 4)
    }
}

// MARK: - Кнопка вибору теми

private struct ThemeOptionButton: View {
    let theme: AppTheme
    let isSelected: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(spacing: 8) {
                Image(systemName: theme.icon)
                    .font(.system(size: 18, weight: .semibold))
                Text(theme.title)
                    .font(.system(.caption, design: .rounded, weight: .medium))
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 14)
            .foregroundStyle(isSelected ? .white : RTheme.ink)
            .background(
                isSelected ? AnyShapeStyle(RTheme.brandGradient) : AnyShapeStyle(RTheme.bgTop),
                in: RoundedRectangle(cornerRadius: 16, style: .continuous)
            )
        }
        .buttonStyle(.plain)
    }
}

// MARK: - Реєстрація / вхід

private struct AuthSection: View {
    @EnvironmentObject private var settings: SettingsStore

    private enum Mode: String, CaseIterable {
        case signIn = "Вхід"
        case register = "Реєстрація"
    }

    @State private var mode: Mode = .register
    @State private var name = ""
    @State private var email = ""
    @State private var password = ""
    @State private var confirmPassword = ""
    @State private var errorText: String?

    var body: some View {
        SettingsCard(title: "Акаунт") {
            Picker("", selection: $mode.animation()) {
                ForEach(Mode.allCases, id: \.self) { Text($0.rawValue).tag($0) }
            }
            .pickerStyle(.segmented)
            .padding(.bottom, 4)

            VStack(spacing: 10) {
                if mode == .register {
                    AuthField(icon: "person", placeholder: "Ім'я", text: $name)
                }
                AuthField(icon: "envelope", placeholder: "Пошта", text: $email, keyboard: .emailAddress)
                AuthField(icon: "lock", placeholder: "Пароль", text: $password, isSecure: true)
                if mode == .register {
                    AuthField(icon: "lock.rotation", placeholder: "Підтвердіть пароль", text: $confirmPassword, isSecure: true)
                }
            }

            if let errorText {
                Text(errorText)
                    .font(.system(.footnote, design: .rounded))
                    .foregroundStyle(.red)
            }

            Button {
                submit()
            } label: {
                Text(mode == .register ? "Зареєструватися" : "Увійти")
                    .font(.system(.subheadline, design: .rounded, weight: .semibold))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 13)
                    .foregroundStyle(.white)
                    .background(RTheme.brandGradient, in: RoundedRectangle(cornerRadius: 14))
            }
            .padding(.top, 6)

            Text("Дані зберігаються лише на цьому пристрої (локально), без сервера.")
                .font(.system(.caption2, design: .rounded))
                .foregroundStyle(RTheme.inkMuted)
                .padding(.top, 2)
        }
    }

    private func submit() {
        errorText = nil
        let trimmedEmail = email.trimmingCharacters(in: .whitespaces)

        guard trimmedEmail.contains("@"), trimmedEmail.contains(".") else {
            errorText = "Введи коректну пошту."
            return
        }
        guard password.count >= 6 else {
            errorText = "Пароль має містити щонайменше 6 символів."
            return
        }

        if mode == .register {
            guard !name.trimmingCharacters(in: .whitespaces).isEmpty else {
                errorText = "Введи ім'я."
                return
            }
            guard password == confirmPassword else {
                errorText = "Паролі не збігаються."
                return
            }
            settings.register(name: name.trimmingCharacters(in: .whitespaces), email: trimmedEmail)
        } else {
            settings.signIn(email: trimmedEmail)
        }
    }
}

private struct AuthField: View {
    let icon: String
    let placeholder: String
    @Binding var text: String
    var keyboard: UIKeyboardType = .default
    var isSecure: Bool = false

    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: icon)
                .font(.system(size: 14, weight: .medium))
                .foregroundStyle(RTheme.inkMuted)
                .frame(width: 18)

            Group {
                if isSecure {
                    SecureField(placeholder, text: $text)
                } else {
                    TextField(placeholder, text: $text)
                        .keyboardType(keyboard)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                }
            }
            .font(.system(.body, design: .rounded))
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 11)
        .background(RTheme.bgTop, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
    }
}

#Preview {
    SettingsView()
        .environmentObject(SettingsStore())
}
