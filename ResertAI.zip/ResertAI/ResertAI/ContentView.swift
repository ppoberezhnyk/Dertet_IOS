//
//  ContentView.swift
//  ResertAI
//
//  Основний екран чат-боту.
//

import SwiftUI

// MARK: - Design tokens

/// Фірмова палітра ResertAI. Кольори адаптивні — самі підлаштовуються
/// під світлу/темну тему, тож окремо дублювати теми для кожного
/// елемента інтерфейсу не потрібно.
enum RTheme {
    static let bgTop = Color.adaptive(
        light: Color(red: 0.90, green: 0.96, blue: 0.93),
        dark: Color(red: 0.06, green: 0.09, blue: 0.08)
    )
    static let bgBottom = Color.adaptive(
        light: Color(red: 0.98, green: 0.98, blue: 0.965),
        dark: Color(red: 0.03, green: 0.035, blue: 0.045)
    )
    static let accentA = Color(red: 0.35, green: 0.47, blue: 1.0)     // індиго
    static let accentB = Color(red: 0.42, green: 0.78, blue: 0.98)    // блакитний
    static let ink = Color.adaptive(
        light: Color(red: 0.11, green: 0.14, blue: 0.13),
        dark: Color(red: 0.95, green: 0.96, blue: 0.96)
    )
    static let inkMuted = Color.adaptive(
        light: Color(red: 0.43, green: 0.47, blue: 0.46),
        dark: Color(red: 0.64, green: 0.67, blue: 0.67)
    )
    static let card = Color.adaptive(
        light: .white,
        dark: Color(red: 0.11, green: 0.12, blue: 0.13)
    )
    static let cardStroke = Color.adaptive(
        light: Color.black.opacity(0.06),
        dark: Color.white.opacity(0.08)
    )
    static let cardShadow = Color.adaptive(
        light: Color.black.opacity(0.08),
        dark: Color.black.opacity(0.5)
    )

    static var brandGradient: LinearGradient {
        LinearGradient(colors: [accentA, accentB], startPoint: .topLeading, endPoint: .bottomTrailing)
    }

    static var backgroundGradient: LinearGradient {
        LinearGradient(colors: [bgTop, bgBottom], startPoint: .top, endPoint: .bottom)
    }
}

extension Color {
    /// Колір, що сам перемикається між світлим і темним варіантом
    /// залежно від поточної теми (системної або примусово заданої
    /// через .preferredColorScheme).
    static func adaptive(light: Color, dark: Color) -> Color {
        Color(UIColor { traits in
            traits.userInterfaceStyle == .dark ? UIColor(dark) : UIColor(light)
        })
    }
}

/// Фірмовий "orb" — коло з градієнтом і іскоркою. Єдиний візуальний
/// підпис застосунку: з'являється в хедері й біля кожної відповіді ШІ.
struct BrandOrb: View {
    var size: CGFloat = 34

    var body: some View {
        ZStack {
            Circle()
                .fill(RTheme.brandGradient)
            Image(systemName: "sparkle")
                .font(.system(size: size * 0.42, weight: .semibold))
                .foregroundStyle(.white)
        }
        .frame(width: size, height: size)
        .shadow(color: RTheme.accentA.opacity(0.35), radius: 6, y: 3)
    }
}

struct ContentView: View {
    @StateObject private var viewModel = ChatViewModel()
    @EnvironmentObject private var settings: SettingsStore
    @FocusState private var inputFocused: Bool
    @State private var showSettings = false

    var body: some View {
        NavigationStack {
            ZStack {
                RTheme.backgroundGradient.ignoresSafeArea()

                VStack(spacing: 0) {
                    header

                    ScrollViewReader { proxy in
                        ScrollView {
                            LazyVStack(alignment: .leading, spacing: 14) {
                                ForEach(viewModel.messages) { message in
                                    MessageBubble(message: message)
                                        .id(message.id)
                                }

                                if viewModel.isLoading {
                                    HStack(spacing: 10) {
                                        BrandOrb(size: 26)
                                        TypingDots()
                                    }
                                    .padding(.leading, 2)
                                }

                                if let error = viewModel.errorMessage {
                                    Text(error)
                                        .font(.footnote)
                                        .foregroundStyle(.red)
                                        .padding(10)
                                        .background(Color.red.opacity(0.08), in: RoundedRectangle(cornerRadius: 12))
                                }
                            }
                            .padding(.horizontal, 16)
                            .padding(.vertical, 12)
                        }
                        .onChange(of: viewModel.messages) { _, newValue in
                            if let last = newValue.last {
                                withAnimation(.easeOut(duration: 0.25)) {
                                    proxy.scrollTo(last.id, anchor: .bottom)
                                }
                            }
                        }
                    }

                    if viewModel.messages.count <= 1 {
                        suggestionChips
                    }

                    inputBar
                }
            }
            .toolbar(.hidden, for: .navigationBar)
            .sheet(isPresented: $showSettings) {
                SettingsView()
                    .environmentObject(settings)
            }
        }
    }

    // MARK: Header

    private var header: some View {
        HStack(spacing: 12) {
            BrandOrb()

            VStack(alignment: .leading, spacing: 1) {
                Text("ResertAI")
                    .font(.system(.headline, design: .rounded, weight: .bold))
                    .foregroundStyle(RTheme.ink)
                Text("на базі Claude")
                    .font(.system(.caption, design: .rounded))
                    .foregroundStyle(RTheme.inkMuted)
            }

            Spacer()

            Button {
                viewModel.clearChat()
            } label: {
                Image(systemName: "arrow.counterclockwise")
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundStyle(RTheme.inkMuted)
                    .padding(9)
                    .background(RTheme.card, in: Circle())
                    .shadow(color: RTheme.cardShadow, radius: 4, y: 2)
            }

            Button {
                showSettings = true
            } label: {
                Image(systemName: "gearshape.fill")
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundStyle(RTheme.inkMuted)
                    .padding(9)
                    .background(RTheme.card, in: Circle())
                    .shadow(color: RTheme.cardShadow, radius: 4, y: 2)
            }
        }
        .padding(.horizontal, 18)
        .padding(.top, 8)
        .padding(.bottom, 12)
    }

    // MARK: Suggestion chips

    private let suggestions: [(icon: String, text: String)] = [
        ("lightbulb", "Дай пораду"),
        ("pencil.line", "Напиши текст"),
        ("questionmark.circle", "Поясни просто"),
        ("globe", "Переклади")
    ]

    private var suggestionChips: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(suggestions, id: \.text) { item in
                    Button {
                        viewModel.inputText = item.text + ": "
                        inputFocused = true
                    } label: {
                        HStack(spacing: 6) {
                            Image(systemName: item.icon)
                                .font(.system(size: 12, weight: .semibold))
                            Text(item.text)
                                .font(.system(.subheadline, design: .rounded, weight: .medium))
                        }
                        .foregroundStyle(RTheme.ink)
                        .padding(.horizontal, 14)
                        .padding(.vertical, 9)
                        .background(RTheme.card, in: Capsule())
                        .overlay(
                            Capsule().stroke(RTheme.cardStroke, lineWidth: 1)
                        )
                        .shadow(color: RTheme.cardShadow, radius: 5, y: 2)
                    }
                }
            }
            .padding(.horizontal, 16)
            .padding(.bottom, 6)
        }
    }

    // MARK: Input bar

    private var inputBar: some View {
        HStack(alignment: .bottom, spacing: 10) {
            TextField("Напиши повідомлення…", text: $viewModel.inputText, axis: .vertical)
                .font(.system(.body, design: .rounded))
                .lineLimit(1...5)
                .padding(.horizontal, 16)
                .padding(.vertical, 12)
                .background(RTheme.card, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 22, style: .continuous)
                        .stroke(RTheme.cardStroke, lineWidth: 1)
                )
                .focused($inputFocused)
                .onSubmit { viewModel.send() }

            Button {
                viewModel.send()
            } label: {
                Image(systemName: "arrow.up")
                    .font(.system(size: 17, weight: .bold))
                    .foregroundStyle(.white)
                    .frame(width: 44, height: 44)
                    .background(
                        canSend ? AnyShapeStyle(RTheme.brandGradient) : AnyShapeStyle(Color.gray.opacity(0.35)),
                        in: Circle()
                    )
                    .shadow(color: canSend ? RTheme.accentA.opacity(0.35) : .clear, radius: 8, y: 4)
            }
            .disabled(!canSend)
            .animation(.easeOut(duration: 0.15), value: canSend)
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 12)
        .background(
            .white.opacity(0.001) // прозора зона для тапів, сама панель без заливки
        )
        .background(.ultraThinMaterial)
    }

    private var canSend: Bool {
        !viewModel.inputText.trimmingCharacters(in: .whitespaces).isEmpty && !viewModel.isLoading
    }
}

// MARK: - Message bubble

private struct MessageBubble: View {
    let message: Message

    var isUser: Bool { message.role == .user }

    var body: some View {
        HStack(alignment: .top, spacing: 8) {
            if isUser {
                Spacer(minLength: 48)
            } else {
                BrandOrb(size: 26)
            }

            Text(message.text)
                .font(.system(.body, design: .rounded))
                .padding(.horizontal, 16)
                .padding(.vertical, 12)
                .foregroundStyle(isUser ? .white : RTheme.ink)
                .background(bubbleBackground)
                .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
                .shadow(color: RTheme.cardShadow, radius: 8, y: 4)

            if !isUser { Spacer(minLength: 48) }
        }
    }

    @ViewBuilder
    private var bubbleBackground: some View {
        if isUser {
            RTheme.brandGradient
        } else {
            RTheme.card
        }
    }
}

// MARK: - Typing indicator

private struct TypingDots: View {
    @State private var phase = 0

    private let timer = Timer.publish(every: 0.35, on: .main, in: .common).autoconnect()

    var body: some View {
        HStack(spacing: 5) {
            ForEach(0..<3) { i in
                Circle()
                    .fill(RTheme.inkMuted.opacity(phase == i ? 1 : 0.3))
                    .frame(width: 6, height: 6)
            }
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 12)
        .background(RTheme.card, in: Capsule())
        .shadow(color: RTheme.cardShadow, radius: 6, y: 3)
        .onReceive(timer) { _ in
            phase = (phase + 1) % 3
        }
    }
}

#Preview {
    ContentView()
}
