//
//  ResertAIApp.swift
//  ResertAI
//
//  Точка входу застосунку.
//

import SwiftUI

@main
struct ResertAIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
