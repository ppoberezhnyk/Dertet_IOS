//
//  ClaudeAPIService.swift
//  ResertAI
//
//  Сервіс для звернення до Anthropic (Claude) API.
//
//  ВАЖЛИВО:
//  1. Встав свій API-ключ у константу `apiKey` нижче (отримати можна на
//     https://console.anthropic.com/settings/keys).
//  2. НІКОЛИ не публікуй застосунок з ключем "в лоб" у продакшн /
//     App Store — ключ буде видно тому, хто розпакує .ipa. Для реального
//     релізу зроби простий бекенд-проксі, який ховає ключ на сервері.
//     Для особистого використання (збірка й встановлення собі на телефон)
//     так робити можна.
//

import Foundation

enum ClaudeAPIError: Error, LocalizedError {
    case missingAPIKey
    case badResponse(String)
    case network(Error)
    case timedOut

    var errorDescription: String? {
        switch self {
        case .missingAPIKey:
            return "Не вказано API-ключ. Відкрий ClaudeAPIService.swift і встав свій ключ у константу apiKey."
        case .badResponse(let msg):
            return "Помилка відповіді сервера: \(msg)"
        case .network(let err):
            return "Мережева помилка: \(err.localizedDescription)"
        case .timedOut:
            return "Режим \"Думає\" не встиг за 30 секунд. Спробуй ще раз або постав простіше запитання."
        }
    }
}

/// Два окремі режими роботи чат-бота.
enum ChatMode: String, CaseIterable, Identifiable {
    /// Звичайна швидка відповідь.
    case quick
    /// Розширене мислення — модель обмірковує відповідь довше
    /// (до ~30 секунд), перш ніж відповісти.
    case thinking

    var id: String { rawValue }

    var title: String {
        switch self {
        case .quick: return "Швидко"
        case .thinking: return "Думає"
        }
    }

    var icon: String {
        switch self {
        case .quick: return "bolt.fill"
        case .thinking: return "brain.head.profile"
        }
    }
}

final class ClaudeAPIService {

    // MARK: - Налаштування

    /// Встав сюди свій ключ Anthropic API, наприклад: "sk-ant-api03-...."
    private let apiKey: String = "ВСТАВ_СВІЙ_API_КЛЮЧ_СЮДИ"

    /// Модель, яку буде використовувати чат-бот.
    private let model: String = "claude-sonnet-5"

    /// Скільки максимум секунд чекати відповідь у режимі "Думає".
    private let thinkingTimeout: TimeInterval = 30

    private let endpoint = URL(string: "https://api.anthropic.com/v1/messages")!

    // MARK: - API

    struct ChatMessage {
        let role: String // "user" або "assistant"
        let content: String
    }

    struct Reply {
        let text: String
        /// Хід міркувань моделі — заповнено лише коли mode == .thinking.
        let thinking: String?
    }

    /// Надсилає всю історію діалогу та повертає відповідь асистента.
    /// У режимі .thinking запит автоматично обривається через ~30 сек,
    /// якщо модель не встигла відповісти.
    func sendMessage(history: [ChatMessage], mode: ChatMode) async throws -> Reply {
        guard !apiKey.isEmpty, apiKey != "ВСТАВ_СВІЙ_API_КЛЮЧ_СЮДИ" else {
            throw ClaudeAPIError.missingAPIKey
        }

        var request = URLRequest(url: endpoint)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue(apiKey, forHTTPHeaderField: "x-api-key")
        request.setValue("2023-06-01", forHTTPHeaderField: "anthropic-version")

        var body: [String: Any] = [
            "model": model,
            "messages": history.map { ["role": $0.role, "content": $0.content] }
        ]

        switch mode {
        case .quick:
            body["max_tokens"] = 1024
            request.timeoutInterval = 60
        case .thinking:
            // budget_tokens — скільки "думати" перед відповіддю;
            // max_tokens має бути більшим за budget_tokens.
            body["max_tokens"] = 8000
            body["thinking"] = [
                "type": "enabled",
                "budget_tokens": 6000
            ]
            request.timeoutInterval = thinkingTimeout
        }

        request.httpBody = try JSONSerialization.data(withJSONObject: body)

        let (data, response): (Data, URLResponse)
        do {
            (data, response) = try await URLSession.shared.data(for: request)
        } catch {
            let nsError = error as NSError
            if nsError.code == NSURLErrorTimedOut {
                throw ClaudeAPIError.timedOut
            }
            throw ClaudeAPIError.network(error)
        }

        guard let http = response as? HTTPURLResponse else {
            throw ClaudeAPIError.badResponse("Немає HTTP-відповіді")
        }

        guard (200...299).contains(http.statusCode) else {
            let text = String(data: data, encoding: .utf8) ?? "невідома помилка"
            throw ClaudeAPIError.badResponse("Код \(http.statusCode): \(text)")
        }

        guard
            let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
            let content = json["content"] as? [[String: Any]]
        else {
            throw ClaudeAPIError.badResponse("Не вдалося розпарсити відповідь")
        }

        var answerText = ""
        var thinkingText = ""

        for block in content {
            guard let type = block["type"] as? String else { continue }
            switch type {
            case "text":
                answerText += (block["text"] as? String ?? "")
            case "thinking":
                thinkingText += (block["thinking"] as? String ?? "")
            default:
                break
            }
        }

        let finalText = answerText.isEmpty ? "(порожня відповідь)" : answerText
        return Reply(text: finalText, thinking: thinkingText.isEmpty ? nil : thinkingText)
    }
}
