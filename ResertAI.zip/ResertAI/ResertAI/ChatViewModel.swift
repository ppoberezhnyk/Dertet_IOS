//
//  ChatViewModel.swift
//  ResertAI
//
//  Логіка чату: зберігає повідомлення, кличе API, керує станом.
//

import Foundation
import SwiftUI

@MainActor
final class ChatViewModel: ObservableObject {

    @Published var messages: [Message] = [
        Message(role: .assistant, text: "Привіт! Я ResertAI 👋 Онлайн-помічник на базі Gemini. Постав мені будь-яке питання.")
    ]
    @Published var inputText: String = ""
    @Published var isLoading: Bool = false
    @Published var errorMessage: String?

    /// Поточний режим: .quick — звичайна швидка відповідь,
    /// .thinking — розширене мислення (до ~30 сек).
    @Published var mode: ChatMode = .quick

    private let api = GeminiAPIService()

    func send() {
        let trimmed = inputText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty, !isLoading else { return }

        let userMessage = Message(role: .user, text: trimmed)
        messages.append(userMessage)
        inputText = ""
        errorMessage = nil
        isLoading = true

        let history = messages.map {
            GeminiAPIService.ChatMessage(
                role: $0.role == .user ? "user" : "assistant",
                content: $0.text
            )
        }

        let currentMode = mode

        Task {
            do {
                let reply = try await api.sendMessage(history: history, mode: currentMode)
                messages.append(Message(role: .assistant, text: reply.text, thinking: reply.thinking))
            } catch {
                errorMessage = error.localizedDescription
            }
            isLoading = false
        }
    }

    func clearChat() {
        messages = [
            Message(role: .assistant, text: "Чат очищено. Чим можу допомогти?")
        ]
        errorMessage = nil
    }
}
