//
//  Message.swift
//  ResertAI
//
//  Модель одного повідомлення в чаті.
//

import Foundation

struct Message: Identifiable, Equatable {
    enum Role: String {
        case user
        case assistant
    }

    let id: UUID = UUID()
    let role: Role
    var text: String
    var isStreaming: Bool = false
}
