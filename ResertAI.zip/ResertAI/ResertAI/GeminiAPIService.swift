//
//  GeminiAPIService.swift
//  ResertAI
//
//  Сервіс для звернення до Google Gemini API — має справжній
//  безкоштовний рівень (без карти, ліміт запитів оновлюється щодня,
//  на відміну від одноразового пробного кредиту в Anthropic).
//
//  ВАЖЛИВО:
//  1. Встав свій API-ключ у константу `apiKey` нижче. Отримати можна
//     безкоштовно на https://aistudio.google.com/apikey — досить
//     увійти гугл-акаунтом, картка не потрібна.
//  2. НІКОЛИ не публікуй застосунок з ключем "в лоб" у продакшн /
//     App Store — ключ буде видно тому, хто розпакує .ipa. Для
//     реального релізу зроби простий бекенд-проксі, який ховає ключ
//     на сервері. Для особистого використання (збірка й встановлення
//     собі на телефон) так робити можна.
//  3. Безкоштовний рівень має денний ліміт запитів (оновлюється щодня)
//     і Google може використовувати запити/відповіді для покращення
//     своїх продуктів — це офіційна умова безкоштовного рівня.
//

import Foundation

enum GeminiAPIError: Error, LocalizedError {
    case missingAPIKey
    case badResponse(String)
    case network(Error)
    case timedOut

    var errorDescription: String? {
        switch self {
        case .missingAPIKey:
            return "Не вказано API-ключ. Відкрий GeminiAPIService.swift і встав свій ключ у константу apiKey."
        case .badResponse(let msg):
            return "Помилка відповіді сервера: \(msg)"
        case .network(let err):
            return "Мережева помилка: \(err.localizedDescription)"
        case .timedOut:
            return "Режим \"Думає\" не встиг за 30 секунд. Спробуй ще раз або постав простіше запитання."
        }
    }
}

/// Два окремі режими роботи чат-бота.
enum ChatMode: String, CaseIterable, Identifiable {
    /// Звичайна швидка відповідь (мислення вимкнене).
    case quick
    /// Розширене мислення — модель обмірковує відповідь довше
    /// (до ~30 секунд), перш ніж відповісти.
    case thinking

    var id: String { rawValue }

    var title: String {
        switch self {
        case .quick: return "Швидко"
        case .thinking: return "Думає"
        }
    }

    var icon: String {
        switch self {
        case .quick: return "bolt.fill"
        case .thinking: return "brain.head.profile"
        }
    }
}

final class GeminiAPIService {

    // MARK: - Налаштування

    /// Встав сюди свій ключ Google AI Studio, наприклад: "AIzaSy...."
    private let apiKey: String = "AQ.Ab8RN6LuNFJxPGv1dkHIYBxU-gC7KuS0XyYpy4BtEP-Ff-jEnw"

    /// Модель — Flash доступна на безкоштовному рівні.
    private let model: String = "gemini-2.5-flash"

    /// Скільки максимум секунд чекати відповідь у режимі "Думає".
    private let thinkingTimeout: TimeInterval = 30

    private var endpoint: URL {
        URL(string: "https://generativelanguage.googleapis.com/v1beta/models/\(model):generateContent")!
    }

    // MARK: - API

    struct ChatMessage {
        let role: String // "user" або "assistant"
        let content: String
    }

    struct Reply {
        let text: String
        /// Хід міркувань моделі — заповнено лише коли mode == .thinking
        /// і Gemini повернув короткий підсумок міркувань.
        let thinking: String?
    }

    /// Надсилає всю історію діалогу та повертає відповідь асистента.
    /// У режимі .thinking запит автоматично обривається через ~30 сек,
    /// якщо модель не встигла відповісти.
    func sendMessage(history: [ChatMessage], mode: ChatMode) async throws -> Reply {
        guard !apiKey.isEmpty, apiKey != "ВСТАВ_СВІЙ_API_КЛЮЧ_СЮДИ" else {
            throw GeminiAPIError.missingAPIKey
        }

        var request = URLRequest(url: endpoint)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue(apiKey, forHTTPHeaderField: "x-goog-api-key")

        // Gemini використовує role "model" замість "assistant".
        let contents = history.map { msg -> [String: Any] in
            [
                "role": msg.role == "assistant" ? "model" : "user",
                "parts": [["text": msg.content]]
            ]
        }

        var generationConfig: [String: Any] = [:]
        switch mode {
        case .quick:
            // thinkingBudget: 0 — вимикає "роздуми", відповідь швидша.
            generationConfig["thinkingConfig"] = ["thinkingBudget": 0]
            request.timeoutInterval = 60
        case .thinking:
            // includeThoughts: true — просимо короткий підсумок ходу міркувань.
            generationConfig["thinkingConfig"] = [
                "thinkingBudget": 8000,
                "includeThoughts": true
            ]
            request.timeoutInterval = thinkingTimeout
        }

        let body: [String: Any] = [
            "contents": contents,
            "generationConfig": generationConfig
        ]

        request.httpBody = try JSONSerialization.data(withJSONObject: body)

        let (data, response): (Data, URLResponse)
        do {
            (data, response) = try await URLSession.shared.data(for: request)
        } catch {
            let nsError = error as NSError
            if nsError.code == NSURLErrorTimedOut {
                throw GeminiAPIError.timedOut
            }
            throw GeminiAPIError.network(error)
        }

        guard let http = response as? HTTPURLResponse else {
            throw GeminiAPIError.badResponse("Немає HTTP-відповіді")
        }

        guard (200...299).contains(http.statusCode) else {
            let text = String(data: data, encoding: .utf8) ?? "невідома помилка"
            throw GeminiAPIError.badResponse("Код \(http.statusCode): \(text)")
        }

        guard
            let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
            let candidates = json["candidates"] as? [[String: Any]],
            let first = candidates.first,
            let contentObj = first["content"] as? [String: Any],
            let parts = contentObj["parts"] as? [[String: Any]]
        else {
            throw GeminiAPIError.badResponse("Не вдалося розпарсити відповідь")
        }

        var answerText = ""
        var thinkingText = ""

        for part in parts {
            let text = part["text"] as? String ?? ""
            let isThought = (part["thought"] as? Bool) ?? false
            if isThought {
                thinkingText += text
            } else {
                answerText += text
            }
        }

        let finalText = answerText.isEmpty ? "(порожня відповідь)" : answerText
        return Reply(text: finalText, thinking: thinkingText.isEmpty ? nil : thinkingText)
    }
}
