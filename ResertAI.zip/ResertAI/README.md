# ResertAI

Простий iOS-чатбот на SwiftUI, підключений до Claude (Anthropic API).

## Що всередині

- `ResertAIApp.swift` — точка входу.
- `ContentView.swift` — екран чату (бульбашки повідомлень, поле вводу).
- `ChatViewModel.swift` — логіка чату та стан.
- `ClaudeAPIService.swift` — звернення до Anthropic API.
- `Message.swift` — модель повідомлення.

## Кроки перед збіркою

1. Відкрий `ResertAI.xcodeproj` в Xcode (15.2+, iOS 16+ SDK).
2. Відкрий `ClaudeAPIService.swift` і встав свій API-ключ у рядок:
   ```swift
   private let apiKey: String = "ВСТАВ_СВІЙ_API_КЛЮЧ_СЮДИ"
   ```
   Ключ отримуєш на https://console.anthropic.com/settings/keys
   (потрібно поповнити баланс на цьому акаунті — API платний, окремо від підписки Claude.ai).
3. За бажанням зміни `Bundle Identifier` у Signing & Capabilities (зараз `com.resertai.app`) та назву проєкту/іконку.
4. У Signing & Capabilities вибери свій Apple ID (Team) для підпису.
5. Підключи iPhone або обери симулятор і натисни ▶️ (Run) — або зроби Archive → Distribute App, щоб отримати `.ipa`.

## Важливо про безпеку ключа

Ключ, вписаний прямо в код, буде видно будь-кому, хто розпакує `.ipa`
(це звичайний zip-архів). Для особистого використання (сам зібрав — сам
поставив собі на телефон) це нормально. Якщо плануєш роздавати застосунок
іншим людям — потрібен бекенд-проксі, який ховає ключ на сервері, а
застосунок звертається до твого сервера, а не напряму до Anthropic.

## Модель

За замовчуванням використовується `claude-sonnet-5`. Змінити можна в
`ClaudeAPIService.swift`, константа `model`.
