# ResertAI

Простий iOS-чатбот на SwiftUI, підключений до **Groq API**
(безкоштовний рівень — без карти, дуже швидкий завдяки власним
LPU-чипам, ліміт запитів оновлюється щодня).

## Що всередині

- `ResertAIApp.swift` — точка входу.
- `ContentView.swift` — екран чату (бульбашки повідомлень, поле вводу, режими).
- `ChatViewModel.swift` — логіка чату та стан.
- `GroqAPIService.swift` — звернення до Groq API.
- `Message.swift` — модель повідомлення.
- `Palette.swift` — палітри фону (можна перемикати в Налаштуваннях).
- `SettingsStore.swift` / `SettingsView.swift` — тема, палітра, локальний акаунт.

## Кроки перед збіркою

1. Відкрий `ResertAI.xcodeproj` в Xcode (15.2+, iOS 16+ SDK).
2. Отримай безкоштовний ключ на https://console.groq.com/keys
   (вхід через Google/GitHub/пошту, картка не потрібна).
3. Відкрий `GroqAPIService.swift` і встав свій ключ у рядок:
   ```swift
   private let apiKey: String = "ВСТАВ_СВІЙ_API_КЛЮЧ_СЮДИ"
   ```
   Ключ виглядає як `gsk_...`.
4. За бажанням зміни `Bundle Identifier` у Signing & Capabilities (зараз `com.resertai.app`) та назву проєкту/іконку.
5. У Signing & Capabilities вибери свій Apple ID (Team) для підпису.
6. Підключи iPhone або обери симулятор і натисни ▶️ (Run) — або зроби Archive → Distribute App, щоб отримати `.ipa`.

## Про безкоштовний рівень Groq

- Не потрібна картка, ліміт запитів оновлюється щодня.
- Модель швидкого режиму — `openai/gpt-oss-20b`.
- Модель режиму "Думає" — `openai/gpt-oss-120b` (reasoning-модель, ліміт нижчий за швидку).
- Якщо застосунок почне відповідати помилкою з кодом 429 — це означає, що денний ліміт вичерпано, спробуй пізніше.

## Важливо про безпеку ключа

Ключ, вписаний прямо в код, буде видно будь-кому, хто розпакує `.ipa`
(це звичайний zip-архів). Для особистого використання (сам зібрав — сам
поставив собі на телефон) це нормально. Якщо плануєш роздавати застосунок
іншим людям — потрібен бекенд-проксі, який ховає ключ на сервері, а
застосунок звертається до твого сервера, а не напряму до Groq.

## Режими

- **Швидко** — модель `openai/gpt-oss-20b`, миттєва відповідь.
- **Думає** — reasoning-модель `openai/gpt-oss-120b`, до 30 секунд, з ходом міркувань під відповіддю.

## Mac (Catalyst)

Проєкт налаштований так, що той самий код можна запустити і як
нативний застосунок на Mac (Apple Silicon) — через **Mac Catalyst**,
без жодних додаткових змін коду.

**Як запустити на Mac:**

1. Відкрий `ResertAI.xcodeproj` в Xcode на Mac.
2. У списку пристроїв зверху (де вибираєш симулятор) обери
   **"My Mac"** (може називатися "My Mac (Mac Catalyst)" або
   "My Mac (Designed for iPad)" — обидва варіанти підходять).
3. Натисни ▶️ (Run) — застосунок відкриється як звичайне Mac-вікно.

**Як зробити `.dmg`, щоб роздати комусь на іншому Mac:**

Xcode не створює `.dmg` напряму, але останній крок — дві хвилини в
стандартних інструментах macOS, без жодних сторонніх програм:

1. У Xcode: **Product → Archive** (обравши "My Mac" як пристрій).
2. У вікні Organizer, що відкриється, натисни **Distribute App →
   Copy App** (для особистого використання підпис Developer ID не
   обов'язковий — вистачить "Copy App"). Отримаєш `ResertAI.app`.
3. Відкрий програму **Disk Utility** (Дисковий інструмент) → File →
   **New Image → Image from Folder…** → обери щойно збережений
   `ResertAI.app` → Save. Це і буде готовий `.dmg`.

Порада: якщо відкриєш `.app` без підпису Developer ID вперше, macOS
спитає підтвердження в Налаштуваннях → Конфіденційність і безпека —
це нормально для незареєстрованих у Apple застосунків.

## Нові можливості: збереження чатів, Google, email

### Збереження чатів

Історія чату автоматично зберігається на диску (`ChatStorage.swift`) і
відновлюється при наступному запуску. Файл лежить у Documents
застосунку і видимий у **Файлах на iPhone**: Файли → На iPhone →
ResertAI → `chat-history.json`. Це працює одразу, без жодних
додаткових налаштувань.

### Email-сповіщення при реєстрації (через EmailJS)

З телефону не можна напряму відправити лист через SMTP без сервера,
тому використано **EmailJS** — сервіс, спеціально зроблений для
відправки листів прямо з коду застосунку.

1. Зареєструйся безкоштовно на https://www.emailjs.com
2. **Email Services** → підключи свою пошту → скопіюй **Service ID**.
3. **Email Templates** → створи шаблон (поле "To email" = `{{to_email}}`,
   у тілі листа можна використати `{{to_name}}`) → скопіюй **Template ID**.
4. **Account → General** → скопіюй **Public Key**.
5. **Account → Security** → увімкни **"Allow API calls from non-browser
   applications"** — без цього кроку запити з телефону блокуються
   (EmailJS за замовчуванням дозволяє запити лише з браузера).
6. Встав усі три значення в `EmailNotifier.swift`.

Лист автоматично надсилається на пошту, яку людина вказала при
реєстрації в застосунку.

### Реєстрація через Google

Код підготовлено в `GoogleAuthService.swift`, але він **закоментований** —
проєкт має компілюватись і без пакета Google, поки ти його не додав.
Кроки (усі — одноразові):

1. У Xcode: **File → Add Package Dependencies…** → встав
   `https://github.com/google/GoogleSignIn-iOS` → Add Package → обери
   продукт **GoogleSignIn** для таргету ResertAI.
2. Створи OAuth Client ID на https://console.cloud.google.com
   (APIs & Services → Credentials → Create Credentials → OAuth client ID
   → тип **iOS**, Bundle ID такий самий, як у Xcode).
3. Встав отриманий Client ID у `GoogleAuthService.swift`.
4. У Xcode: таргет ResertAI → вкладка **Info** → **URL Types** → "+" →
   встав Client ID задом наперед (наприклад
   `123456-xxxx.apps.googleusercontent.com` → URL Scheme
   `com.googleusercontent.apps.123456-xxxx`).
5. Розкоментуй весь код у `GoogleAuthService.swift` і заміни тіло
   функції `signInWithGoogle()` в `SettingsView.swift` на реальний
   виклик `GoogleAuthService.signIn()`.

Поки ці кроки не виконано, кнопка "Увійти через Google" у застосунку
просто показує підказку з нагадуванням, що робити — це навмисно, щоб
проєкт відкривався й компілювався одразу після завантаження.

## Моделі

Змінити можна в `GroqAPIService.swift`, константи `quickModel` і
`thinkingModel`. Повний список доступних моделей — на
https://console.groq.com/docs/models


