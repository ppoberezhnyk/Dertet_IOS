//
//  ChatViewModel.swift
//  ResertAI
//
//  Логіка чату: зберігає повідомлення, кличе API, керує станом.
//  Історія автоматично зберігається на диск і відновлюється при
//  наступному запуску застосунку (ChatStorage.swift).
//

import Foundation
import SwiftUI

@MainActor
final class ChatViewModel: ObservableObject {

    private static let greeting = Message(
        role: .assistant,
        text: "Привіт! Я ResertAI 👋 Онлайн-помічник на базі Groq (Llama). Постав мені будь-яке питання."
    )

    @Published var messages: [Message] {
        didSet {
            // Зберігаємо лише якщо автозбереження увімкнено в Налаштуваннях
            // (за замовчуванням — увімкнено, див. SettingsStore.autosaveChats).
            guard UserDefaults.standard.bool(forKey: "resertai.autosaveChats") else { return }
            ChatStorage.save(messages)
        }
    }
    @Published var inputText: String = ""
    @Published var isLoading: Bool = false
    @Published var errorMessage: String?

    /// Поточний режим: .quick — звичайна швидка відповідь,
    /// .thinking — розширене мислення (до ~30 сек).
    @Published var mode: ChatMode = .quick

    private let api = GroqAPIService()

    init() {
        // Відновлюємо збережену історію, якщо вона є; інакше — привітання.
        if let saved = ChatStorage.load(), !saved.isEmpty {
            messages = saved
        } else {
            messages = [Self.greeting]
        }
    }

    func send() {
        let trimmed = inputText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty, !isLoading else { return }

        let userMessage = Message(role: .user, text: trimmed)
        messages.append(userMessage)
        inputText = ""
        errorMessage = nil
        isLoading = true

        let history = messages.map {
            GroqAPIService.ChatMessage(
                role: $0.role == .user ? "user" : "assistant",
                content: $0.text
            )
        }

        let currentMode = mode

        Task {
            do {
                let reply = try await api.sendMessage(history: history, mode: currentMode)
                messages.append(Message(role: .assistant, text: reply.text, thinking: reply.thinking))
            } catch {
                errorMessage = error.localizedDescription
            }
            isLoading = false
        }
    }

    func clearChat() {
        messages = [
            Message(role: .assistant, text: "Чат очищено. Чим можу допомогти?")
        ]
        errorMessage = nil
    }

    /// Повністю видаляє збережений на диску файл історії (незалежно від
    /// того, увімкнено автозбереження чи ні) і скидає чат до привітання.
    /// Викликається з Налаштувань.
    func deleteSavedHistory() {
        ChatStorage.clear()
        messages = [
            Message(role: .assistant, text: "Історію видалено. Чим можу допомогти?")
        ]
        errorMessage = nil
    }
}
