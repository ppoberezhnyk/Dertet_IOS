//
//  EmailNotifier.swift
//  ResertAI
//
//  Відправляє email-сповіщення через EmailJS — сервіс, спеціально
//  зроблений для відправки листів прямо з коду застосунку, без
//  власного сервера (звичайний SMTP з телефону відправити не можна).
//
//  ВАЖЛИВО, ЩОБ ЗАПРАЦЮВАЛО:
//  1. Зареєструйся безкоштовно на https://www.emailjs.com
//  2. Email Services → підключи свою пошту (Gmail тощо) → скопіюй
//     Service ID.
//  3. Email Templates → створи шаблон листа (наприклад "Ласкаво
//     просимо, {{to_name}}!") → скопіюй Template ID. У шаблоні поле
//     "To email" встанови як {{to_email}}.
//  4. Account → General → скопіюй Public Key.
//  5. Account → Security → увімкни "Allow API calls from
//     non-browser applications" (без цього запити з телефону
//     блокуватимуться — за замовчуванням EmailJS дозволяє запити
//     лише з браузера).
//  6. Встав усі три значення нижче замість заглушок.
//

import Foundation

enum EmailNotifierError: Error, LocalizedError {
    case notConfigured
    case badResponse(String)

    var errorDescription: String? {
        switch self {
        case .notConfigured:
            return "Email-сповіщення не налаштовані. Відкрий EmailNotifier.swift і встав свої дані з EmailJS."
        case .badResponse(let msg):
            return "EmailJS повернув помилку: \(msg)"
        }
    }
}

enum EmailNotifier {

    // MARK: - Налаштування (заповни зі свого акаунту EmailJS)

    private static let serviceID = "ВСТАВ_SERVICE_ID"
    private static let templateID = "ВСТАВ_TEMPLATE_ID"
    private static let publicKey = "ВСТАВ_PUBLIC_KEY"

    private static let endpoint = URL(string: "https://api.emailjs.com/api/v1.0/email/send")!

    /// Надсилає лист на вказану пошту (наприклад, після реєстрації).
    /// `name` і `email` підставляються в шаблон листа як
    /// {{to_name}} і {{to_email}}.
    static func sendWelcomeEmail(toName name: String, toEmail email: String) async throws {
        guard serviceID != "ВСТАВ_SERVICE_ID",
              templateID != "ВСТАВ_TEMPLATE_ID",
              publicKey != "ВСТАВ_PUBLIC_KEY" else {
            throw EmailNotifierError.notConfigured
        }

        var request = URLRequest(url: endpoint)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        let body: [String: Any] = [
            "service_id": serviceID,
            "template_id": templateID,
            "user_id": publicKey,
            "template_params": [
                "to_name": name,
                "to_email": email
            ]
        ]

        request.httpBody = try JSONSerialization.data(withJSONObject: body)

        let (data, response) = try await URLSession.shared.data(for: request)

        guard let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode) else {
            let text = String(data: data, encoding: .utf8) ?? "невідома помилка"
            throw EmailNotifierError.badResponse(text)
        }
    }
}
