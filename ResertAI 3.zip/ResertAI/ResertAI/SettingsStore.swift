//
//  SettingsStore.swift
//  ResertAI
//
//  Тема оформлення та локальний "акаунт" (без сервера).
//
//  ВАЖЛИВО: реєстрація тут повністю локальна — ім'я/пошта зберігаються
//  в UserDefaults на самому пристрої, пароль ніде не зберігається у
//  відкритому вигляді і не перевіряється на сервері, бо сервера немає.
//  Це підходить, щоб показати екран "як буде виглядати" авторизація.
//  Для реального акаунту (з відновленням пароля, синхронізацією між
//  пристроями тощо) потрібен бекенд — наприклад, Firebase Auth,
//  Supabase Auth або власний сервер. Скажи, якщо хочеш, щоб я підключив
//  один з них.
//

import Foundation
import SwiftUI

enum AppTheme: String, CaseIterable, Identifiable {
    case system
    case light
    case dark

    var id: String { rawValue }

    var title: String {
        switch self {
        case .system: return "Система"
        case .light: return "Світла"
        case .dark: return "Темна"
        }
    }

    var icon: String {
        switch self {
        case .system: return "circle.lefthalf.filled"
        case .light: return "sun.max.fill"
        case .dark: return "moon.fill"
        }
    }

    var colorScheme: ColorScheme? {
        switch self {
        case .system: return nil
        case .light: return .light
        case .dark: return .dark
        }
    }
}

@MainActor
final class SettingsStore: ObservableObject {

    @AppStorage("resertai.theme") var themeRaw: String = AppTheme.system.rawValue {
        didSet { objectWillChange.send() }
    }

    var theme: AppTheme {
        get { AppTheme(rawValue: themeRaw) ?? .system }
        set { themeRaw = newValue.rawValue }
    }

    @AppStorage("resertai.palette") var paletteId: String = AppPalette.mint.id {
        didSet { objectWillChange.send() }
    }

    var palette: AppPalette {
        get { AppPalette.all.first { $0.id == paletteId } ?? .mint }
        set { paletteId = newValue.id }
    }

    // MARK: - Історія чату

    /// Чи зберігати історію чату на диск автоматично. Увімкнено
    /// за замовчуванням (значення реєструється в UserDefaults ще до
    /// створення першого ChatViewModel — див. ResertAIApp.init).
    @AppStorage("resertai.autosaveChats") var autosaveChats: Bool = true {
        didSet { objectWillChange.send() }
    }

    // MARK: - Локальний акаунт

    @AppStorage("resertai.account.name") var accountName: String = ""
    @AppStorage("resertai.account.email") var accountEmail: String = ""
    @AppStorage("resertai.account.loggedIn") var isLoggedIn: Bool = false

    func register(name: String, email: String) {
        accountName = name
        accountEmail = email
        isLoggedIn = true
    }

    func signIn(email: String) {
        accountEmail = email
        if accountName.isEmpty { accountName = String(email.split(separator: "@").first ?? "") }
        isLoggedIn = true
    }

    func signOut() {
        isLoggedIn = false
    }
}
