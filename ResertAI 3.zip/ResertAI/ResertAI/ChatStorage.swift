//
//  ChatStorage.swift
//  ResertAI
//
//  Зберігає історію чату у файл. Файл лежить у папці Documents
//  застосунку.
//
//  На iPhone/iPad (за умови увімкненого File Sharing в Info.plist,
//  він уже увімкнений) файл видимий у застосунку "Файли": Файли →
//  На iPhone → ResertAI → chat-history.json.
//
//  На Mac (Mac Catalyst) немає застосунку "Файли" — натомість у
//  Налаштуваннях є кнопка "Показати файл…", яка відкриває стандартне
//  вікно "Поділитися", звідки файл можна зберегти у Finder, надіслати
//  через AirDrop тощо.
//

import Foundation

enum ChatStorage {

    private static var fileURL: URL {
        let documents = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        return documents.appendingPathComponent("chat-history.json")
    }

    static func save(_ messages: [Message]) {
        do {
            let data = try JSONEncoder().encode(messages)
            try data.write(to: fileURL, options: .atomic)
        } catch {
            print("ResertAI: не вдалося зберегти чат — \(error.localizedDescription)")
        }
    }

    static func load() -> [Message]? {
        guard let data = try? Data(contentsOf: fileURL) else { return nil }
        return try? JSONDecoder().decode([Message].self, from: data)
    }

    static func clear() {
        try? FileManager.default.removeItem(at: fileURL)
    }

    /// Чи існує вже збережений файл історії на диску.
    static var fileExists: Bool {
        FileManager.default.fileExists(atPath: fileURL.path)
    }

    /// Дата останнього збереження файлу (якщо він існує).
    static var lastSavedAt: Date? {
        guard let attrs = try? FileManager.default.attributesOfItem(atPath: fileURL.path) else { return nil }
        return attrs[.modificationDate] as? Date
    }

    /// URL файлу для показу в UI (наприклад, у "Поділитись" з Налаштувань).
    static var fileURLForSharing: URL { fileURL }
}
