//
//  ResertAIApp.swift
//  ResertAI
//
//  Точка входу застосунку.
//

import SwiftUI

@main
struct ResertAIApp: App {
    @StateObject private var settings = SettingsStore()

    init() {
        // Реєструємо дефолт "зберігати історію чату = увімкнено" ще до
        // того, як ChatViewModel уперше прочитає це значення. Завдяки
        // цьому автозбереження працює одразу після першого запуску,
        // без потреби заходити в Налаштування.
        UserDefaults.standard.register(defaults: ["resertai.autosaveChats": true])
    }

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(settings)
                .preferredColorScheme(settings.theme.colorScheme)
                // На Mac (Mac Catalyst) ці значення задають початковий і
                // мінімальний розмір вікна замість розтягнутого на весь
                // екран телефонного макета. На iPhone/iPad не впливають.
                .frame(minWidth: 380, idealWidth: 460, maxWidth: 640,
                       minHeight: 560, idealHeight: 760)
        }
    }
}
