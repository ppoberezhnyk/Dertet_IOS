//
//  ResertAIApp.swift
//  ResertAI
//
//  Точка входу застосунку.
//

import SwiftUI

@main
struct ResertAIApp: App {
    @StateObject private var settings = SettingsStore()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(settings)
                .preferredColorScheme(settings.theme.colorScheme)
                #if os(macOS)
                .frame(minWidth: 420, idealWidth: 480, maxWidth: .infinity, minHeight: 560, idealHeight: 760, maxHeight: .infinity)
                #endif
        }
        #if os(macOS)
        .windowResizability(.contentSize)
        .defaultSize(width: 480, height: 760)
        .windowToolbarStyle(.unifiedCompact)
        #endif
    }
}
