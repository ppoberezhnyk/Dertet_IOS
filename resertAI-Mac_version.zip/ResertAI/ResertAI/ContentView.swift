//
//  ContentView.swift
//  ResertAI
//
//  Основний екран чат-боту.
//

import SwiftUI

/// Фірмовий "orb" — коло з градієнтом і іскоркою. Єдиний візуальний
/// підпис застосунку: з'являється в хедері й біля кожної відповіді ШІ.
struct BrandOrb: View {
    @EnvironmentObject private var settings: SettingsStore
    var size: CGFloat = 34

    private var theme: RTheme { RTheme(palette: settings.palette) }

    var body: some View {
        ZStack {
            Circle()
                .fill(theme.brandGradient)
            Image(systemName: "sparkle")
                .font(.system(size: size * 0.42, weight: .semibold))
                .foregroundStyle(.white)
        }
        .frame(width: size, height: size)
        .shadow(color: theme.accentA.opacity(0.35), radius: 6, y: 3)
    }
}

struct ContentView: View {
    @StateObject private var viewModel = ChatViewModel()
    @EnvironmentObject private var settings: SettingsStore
    @FocusState private var inputFocused: Bool
    @State private var showSettings = false

    private var theme: RTheme { RTheme(palette: settings.palette) }

    var body: some View {
        NavigationStack {
            ZStack {
                theme.backgroundGradient.ignoresSafeArea()

                VStack(spacing: 0) {
                    header

                    ScrollViewReader { proxy in
                        ScrollView {
                            LazyVStack(alignment: .leading, spacing: 14) {
                                ForEach(viewModel.messages) { message in
                                    MessageBubble(message: message)
                                        .id(message.id)
                                }

                                if viewModel.isLoading {
                                    HStack(spacing: 10) {
                                        BrandOrb(size: 26)
                                        if viewModel.mode == .thinking {
                                            ThinkingIndicator()
                                        } else {
                                            TypingDots()
                                        }
                                    }
                                    .padding(.leading, 2)
                                }

                                if let error = viewModel.errorMessage {
                                    Text(error)
                                        .font(.footnote)
                                        .foregroundStyle(.red)
                                        .padding(10)
                                        .background(Color.red.opacity(0.08), in: RoundedRectangle(cornerRadius: 12))
                                }
                            }
                            .padding(.horizontal, 16)
                            .padding(.vertical, 12)
                        }
                        .onChange(of: viewModel.messages) { _, newValue in
                            if let last = newValue.last {
                                withAnimation(.easeOut(duration: 0.25)) {
                                    proxy.scrollTo(last.id, anchor: .bottom)
                                }
                            }
                        }
                    }
                    .simultaneousGesture(
                        DragGesture().onChanged { _ in
                            inputFocused = false
                        }
                    )

                    if viewModel.messages.count <= 1 {
                        suggestionChips
                    }

                    modeSwitcher
                    inputBar
                }
            }
            #if os(iOS)
            .toolbar(.hidden, for: .navigationBar)
            #endif
            .sheet(isPresented: $showSettings) {
                SettingsView()
                    .environmentObject(settings)
            }
        }
    }

    // MARK: Header

    private var header: some View {
        HStack(spacing: 12) {
            BrandOrb()

            VStack(alignment: .leading, spacing: 1) {
                Text("ResertAI")
                    .font(.system(.headline, design: .rounded, weight: .bold))
                    .foregroundStyle(theme.ink)
                Text("на базі Groq")
                    .font(.system(.caption, design: .rounded))
                    .foregroundStyle(theme.inkMuted)
            }

            Spacer()

            Button {
                viewModel.clearChat()
            } label: {
                Image(systemName: "arrow.counterclockwise")
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundStyle(theme.inkMuted)
                    .padding(9)
                    .background(theme.card, in: Circle())
                    .shadow(color: theme.cardShadow, radius: 4, y: 2)
            }

            Button {
                showSettings = true
            } label: {
                Image(systemName: "gearshape.fill")
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundStyle(theme.inkMuted)
                    .padding(9)
                    .background(theme.card, in: Circle())
                    .shadow(color: theme.cardShadow, radius: 4, y: 2)
            }
        }
        .padding(.horizontal, 18)
        .padding(.top, 8)
        .padding(.bottom, 12)
    }

    // MARK: Suggestion chips

    private let suggestions: [(icon: String, text: String)] = [
        ("lightbulb", "Дай пораду"),
        ("pencil.line", "Напиши текст"),
        ("questionmark.circle", "Поясни просто"),
        ("globe", "Переклади")
    ]

    private var suggestionChips: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(suggestions, id: \.text) { item in
                    Button {
                        viewModel.inputText = item.text + ": "
                        inputFocused = true
                    } label: {
                        HStack(spacing: 6) {
                            Image(systemName: item.icon)
                                .font(.system(size: 12, weight: .semibold))
                            Text(item.text)
                                .font(.system(.subheadline, design: .rounded, weight: .medium))
                        }
                        .foregroundStyle(theme.ink)
                        .padding(.horizontal, 14)
                        .padding(.vertical, 9)
                        .background(theme.card, in: Capsule())
                        .overlay(
                            Capsule().stroke(theme.cardStroke, lineWidth: 1)
                        )
                        .shadow(color: theme.cardShadow, radius: 5, y: 2)
                    }
                }
            }
            .padding(.horizontal, 16)
            .padding(.bottom, 6)
        }
    }

    // MARK: Режим (Швидко / Думає)

    private var modeSwitcher: some View {
        HStack(spacing: 8) {
            ForEach(ChatMode.allCases) { m in
                let isSelected = viewModel.mode == m

                Button {
                    viewModel.mode = m
                } label: {
                    HStack(spacing: 6) {
                        Image(systemName: m.icon)
                            .font(.system(size: 12, weight: .semibold))
                        Text(m.title)
                            .font(.system(.footnote, design: .rounded, weight: .semibold))
                    }
                    .foregroundStyle(isSelected ? .white : theme.inkMuted)
                    .padding(.horizontal, 14)
                    .padding(.vertical, 8)
                    .background(
                        isSelected ? AnyShapeStyle(theme.brandGradient) : AnyShapeStyle(theme.card),
                        in: Capsule()
                    )
                    .overlay(
                        Capsule().stroke(isSelected ? Color.clear : theme.cardStroke, lineWidth: 1)
                    )
                }
            }

            if viewModel.mode == .thinking {
                Text("до 30 сек")
                    .font(.system(.caption2, design: .rounded))
                    .foregroundStyle(theme.inkMuted)
                    .transition(.opacity)
            }

            Spacer()
        }
        .padding(.horizontal, 16)
        .padding(.bottom, 8)
        .animation(.easeOut(duration: 0.15), value: viewModel.mode)
    }

    // MARK: Input bar

    private var inputBar: some View {
        HStack(alignment: .bottom, spacing: 10) {
            TextField("Напиши повідомлення…", text: $viewModel.inputText, axis: .vertical)
                .font(.system(.body, design: .rounded))
                .lineLimit(1...5)
                .padding(.horizontal, 16)
                .padding(.vertical, 12)
                .background(theme.card, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 22, style: .continuous)
                        .stroke(theme.cardStroke, lineWidth: 1)
                )
                .focused($inputFocused)
                .onSubmit { viewModel.send() }
                #if os(iOS)
                .toolbar {
                    ToolbarItemGroup(placement: .keyboard) {
                        Spacer()
                        Button {
                            inputFocused = false
                        } label: {
                            Image(systemName: "keyboard.chevron.compact.down")
                                .fontWeight(.semibold)
                        }
                    }
                }
                #endif

            Button {
                viewModel.send()
            } label: {
                Image(systemName: "arrow.up")
                    .font(.system(size: 17, weight: .bold))
                    .foregroundStyle(.white)
                    .frame(width: 44, height: 44)
                    .background(
                        canSend ? AnyShapeStyle(theme.brandGradient) : AnyShapeStyle(Color.gray.opacity(0.35)),
                        in: Circle()
                    )
                    .shadow(color: canSend ? theme.accentA.opacity(0.35) : .clear, radius: 8, y: 4)
            }
            .disabled(!canSend)
            .animation(.easeOut(duration: 0.15), value: canSend)
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 12)
        .background(.ultraThinMaterial)
    }

    private var canSend: Bool {
        !viewModel.inputText.trimmingCharacters(in: .whitespaces).isEmpty && !viewModel.isLoading
    }
}

// MARK: - Message bubble

private struct MessageBubble: View {
    @EnvironmentObject private var settings: SettingsStore
    let message: Message

    private var theme: RTheme { RTheme(palette: settings.palette) }
    var isUser: Bool { message.role == .user }

    var body: some View {
        HStack(alignment: .top, spacing: 8) {
            if isUser {
                Spacer(minLength: 48)
            } else {
                BrandOrb(size: 26)
            }

            VStack(alignment: .leading, spacing: 6) {
                if let thinking = message.thinking, !thinking.isEmpty {
                    ThinkingDisclosure(thinking: thinking)
                }

                Text(message.text)
                    .font(.system(.body, design: .rounded))
                    .padding(.horizontal, 16)
                    .padding(.vertical, 12)
                    .foregroundStyle(isUser ? .white : theme.ink)
                    .background(bubbleBackground)
                    .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
                    .shadow(color: theme.cardShadow, radius: 8, y: 4)
            }

            if !isUser { Spacer(minLength: 48) }
        }
    }

    @ViewBuilder
    private var bubbleBackground: some View {
        if isUser {
            theme.brandGradient
        } else {
            theme.card
        }
    }
}

// MARK: - Typing indicator

private struct TypingDots: View {
    @EnvironmentObject private var settings: SettingsStore
    @State private var phase = 0

    private var theme: RTheme { RTheme(palette: settings.palette) }
    private let timer = Timer.publish(every: 0.35, on: .main, in: .common).autoconnect()

    var body: some View {
        HStack(spacing: 5) {
            ForEach(0..<3) { i in
                Circle()
                    .fill(theme.inkMuted.opacity(phase == i ? 1 : 0.3))
                    .frame(width: 6, height: 6)
            }
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 12)
        .background(theme.card, in: Capsule())
        .shadow(color: theme.cardShadow, radius: 6, y: 3)
        .onReceive(timer) { _ in
            phase = (phase + 1) % 3
        }
    }
}

#Preview {
    ContentView()
        .environmentObject(SettingsStore())
}

// MARK: - Хід міркувань (розкривний блок під бульбашкою)

private struct ThinkingDisclosure: View {
    @EnvironmentObject private var settings: SettingsStore
    let thinking: String
    @State private var expanded = false

    private var theme: RTheme { RTheme(palette: settings.palette) }

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Button {
                withAnimation(.easeOut(duration: 0.2)) { expanded.toggle() }
            } label: {
                HStack(spacing: 6) {
                    Image(systemName: "brain.head.profile")
                        .font(.system(size: 11, weight: .semibold))
                    Text(expanded ? "Сховати хід міркувань" : "Показати хід міркувань")
                        .font(.system(.caption, design: .rounded, weight: .medium))
                    Image(systemName: "chevron.down")
                        .font(.system(size: 9, weight: .semibold))
                        .rotationEffect(.degrees(expanded ? 180 : 0))
                }
                .foregroundStyle(theme.inkMuted)
            }

            if expanded {
                Text(thinking)
                    .font(.system(.footnote, design: .rounded))
                    .foregroundStyle(theme.inkMuted)
                    .padding(12)
                    .background(theme.bgTop, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
            }
        }
    }
}

// MARK: - Індикатор "думає" з таймером до 30 сек

private struct ThinkingIndicator: View {
    @EnvironmentObject private var settings: SettingsStore
    @State private var elapsed: Int = 0

    private var theme: RTheme { RTheme(palette: settings.palette) }
    private let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    private let maxSeconds = 30

    var body: some View {
        HStack(spacing: 8) {
            ProgressView()
                .controlSize(.small)
            Text("Думає… \(min(elapsed, maxSeconds)) / \(maxSeconds) сек")
                .font(.system(.subheadline, design: .rounded, weight: .medium))
                .foregroundStyle(theme.inkMuted)
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 12)
        .background(theme.card, in: Capsule())
        .shadow(color: theme.cardShadow, radius: 6, y: 3)
        .onReceive(timer) { _ in
            if elapsed < maxSeconds { elapsed += 1 }
        }
    }
}
